from django.contrib import admin
from .models import Reader

admin.site.register(Reader)
