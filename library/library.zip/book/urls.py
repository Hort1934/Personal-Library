from django.urls import path
from . import views

urlpatterns = [
    path('books/', views.all_books, name='all_books'),
    path('books/<int:book_id>/', views.view_book, name='view_book'),
    path('books/filter/', views.filter_books, name='filter_books'),
    path('users/<int:user_id>/', views.user_books, name='user_books'),
    path('books/add/', views.add_book, name='add_book'),
    path('books/edit/<int:book_id>/', views.edit_book, name='edit_book'),
    path('book/<int:book_id>/delete/', views.delete_book, name='delete_book'),
]
